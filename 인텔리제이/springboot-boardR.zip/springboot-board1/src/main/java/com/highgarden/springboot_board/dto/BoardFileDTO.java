package com.highgarden.springboot_board.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.beans.factory.annotation.Autowired;

@Getter
@Setter
@ToString
public class BoardFileDTO {

    private Long id;
    private Long boardId;
    private String originalFileName;
    private String storedFileName;
}
