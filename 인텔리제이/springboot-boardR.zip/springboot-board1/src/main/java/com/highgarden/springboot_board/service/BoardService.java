package com.highgarden.springboot_board.service;

import com.highgarden.springboot_board.dto.BoardDTO;
import com.highgarden.springboot_board.dto.BoardFileDTO;
import com.highgarden.springboot_board.repository.BoardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BoardService {
   private final BoardRepository boardRepository;

    public void save(BoardDTO boardDto) throws IOException {
        //파일이 없다면 의 뜻
        if(boardDto.getBoardFile().get(0).isEmpty()){
            //파일 없음표시
            boardDto.setFileAttached(0);
            boardRepository.save(boardDto);
            System.out.println("파일없음 저장");
            

        }else{
            //파일 있음 표시
            boardDto.setFileAttached(1);
            System.out.println("파일있음 저장");
            //board를 먼저 insert함
            BoardDTO savedBoard = boardRepository.save(boardDto);
            //파일 처리 후 boardfile insert
            for(MultipartFile boardFile : boardDto.getBoardFile()){
                String originalFileName = boardFile.getOriginalFilename();
                String storedFileName = System.currentTimeMillis()+"_"+originalFileName;

                BoardFileDTO boardFileDTO = new BoardFileDTO();
                boardFileDTO.setOriginalFileName(originalFileName);
                boardFileDTO.setStoredFileName(storedFileName);
                boardFileDTO.setBoardId(savedBoard.getId());
                String savePath = "C:/springboot-board1/src/main/resources/upload_files/"+storedFileName;
                //C:/springboot_board1/src/main/resources/upload_files/ 언더바였셈;
                //저장되는 코드
                boardFile.transferTo(new File(savePath));
                boardRepository.saveFile(boardFileDTO);
                
            }

        }

    }

    public List<BoardDTO> findAll() {
        return boardRepository.findAll();
    }

    public void updateHits(Long id) {
        boardRepository.updateHits(id);

    }

    public BoardDTO findById(Long id) {
        return boardRepository.findById(id);
    }

    public void update(BoardDTO boardDTO) {
        boardRepository.update(boardDTO);
    }

    public void delete(Long id) {
        boardRepository.delete(id);
    }

    public List<BoardFileDTO> findFile(Long id) {
        return boardRepository.findFile(id);
    }
}
