package com.example.firstproject.controller;

import com.example.firstproject.dto.ArticleForm;
import com.example.firstproject.entity.Article;
import com.example.firstproject.repository.ArticleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ArticleController {

    @Autowired //스프링 부트가 미리 생성해 놓은 객체를 가져다가 자동 연결
    private ArticleRepository articleRepository;

    @GetMapping("articles/new")
    public String newArticleForm(){
        return "articles/new";
    }
    //form data 받기
    @PostMapping("/articles/create")
    public String createArticle(ArticleForm form){
        System.out.println(form.toString());

        //1. Dto -> Entity 변환
        Article article = form.toEntity();
        System.out.println(article.toString());
        //2. Repository 에게 Entity 를 DB 안에 저장하게 함
        Article saved = articleRepository.save(article);
        System.out.println(saved.toString());
        return "";
    }

//    @PostMapping("/articles/create")
//    public String createArticle(ArticleForm form){
//        Article article = new Article();
//        article.setTitle(form.getTitle());
//        article.setContent(form.getContent());
//        Article saved = articleRepository.save(article);
//        return "";
//    }
@GetMapping("/articles")
    public String index(Model model){
        //1. 모든 Article 데이터를 가져온다.
   //Iterable<Article> articleEntityList = articleRepository.findAll();

    List<Article> articleEntityList = articleRepository.findAll();
    //2 가져온 Article 묶음을 뷰로 전달
    model.addAttribute("articleList",articleEntityList);
   //3.뷰페이지설정
    return "articles/index";

}

@GetMapping("articles/{id}") //해당 url 요청처리
public String show(@PathVariable Long id, Model model){
        //url 에서 id 변수를 가져옴
    //1.id로 데이터를 가져옴
   Article articleEntity = articleRepository.findById(id).orElse(null);
   //2.가져온데이터를 모뎀에 등록
   model.addAttribute("article",articleEntity);
   //보여줄 페이지를 설정!
    return "articles/show";

}




}
