package com.highgarden.springboot_board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
