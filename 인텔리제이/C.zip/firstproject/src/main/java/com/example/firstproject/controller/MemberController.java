package com.example.firstproject.controller;

import com.example.firstproject.dto.MemberForm;
import com.example.firstproject.entity.Member;
import com.example.firstproject.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class MemberController {

    @GetMapping("articles/new1")
    public String newMemberFrom(){
        return "articles/new1";
    }


    @Autowired //스프링부트가 미리 생성해놓은 객체를 가져다가 자동 연결
    private MemberRepository MemberRepository;

    @PostMapping("/articles/createMember")
    public String createMember(MemberForm form1){

        //1. Dto에 들어있는 애를 entity로 바꿔줘야함
        Member member = form1.Entitify();
        //2. Repository 에게 Entity를 DB안에 저장하게 함
        Member saved = MemberRepository.save(member);
        System.out.println(saved.toString());

        return "articles/new1";

    }
}
