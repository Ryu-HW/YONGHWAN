package com.example.firstproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller //controller 선언
public class FirstController {
    @GetMapping("/hi")
    public  String nice(Model model){

        model.addAttribute("username","준석님!");
        return "greetings";
    }
}
