package example.secondproject.dto;

import example.secondproject.entity.Prod;

public class ProdDto {

    private String comp;
    private String name;
    private String price;

    public ProdDto(String comp, String name, String price) {
        this.comp = comp;
        this.name = name;
        this.price = price;
    }

    public Prod toEntity(){

        return new Prod(null,comp,name,price);

    }
}
