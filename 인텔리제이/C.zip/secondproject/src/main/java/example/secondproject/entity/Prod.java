package example.secondproject.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Prod {

    @Id
    @GeneratedValue
    private Long id;

    @Column
    private String comp;

    @Column
    private String name;

    @Column
    private String price;



    public Prod(Long id, String comp, String name, String price) {
        this.id = id;
        this.comp = comp;
        this.name = name;
        this.price = price;
    }

}
