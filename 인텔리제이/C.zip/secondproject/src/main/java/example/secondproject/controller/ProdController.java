package example.secondproject.controller;

import example.secondproject.dto.ProdDto;
import example.secondproject.entity.Prod;
import example.secondproject.repository.ProdRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ProdController {

    @GetMapping("/prod")
    public String Prods(){
        return "layouts/writeProd";
    }

    @Autowired
    private ProdRepository prodRepository;

    @PostMapping("/writeprod")
    public String setDB(ProdDto p){
        Prod prod = p.toEntity();
        prodRepository.save(prod);

        return "layouts/writeProd";
    }
}
