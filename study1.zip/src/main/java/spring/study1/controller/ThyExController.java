package spring.study1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import spring.study1.dto.ItemDto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Controller
public class ThyExController {
    @GetMapping("ex01")
    public String thyEX01(Model model){
        model.addAttribute("data","타임리프 예제");
        return "thymeleafEx/Ex01.html";
    }

    @GetMapping("abc")
    public String thyEX01_1(Model model){
        model.addAttribute("name","허준석");
        model.addAttribute("phone","010-5898-2103");
        return "thymeleafEx/Ex01_1.html";
    }

    @GetMapping("ex02")
    public String th02_1(Model model){
        ItemDto itemDto = new ItemDto();
        itemDto.setItemDetail("상품 상세 설명");
        itemDto.setItemNm("테스트 상품1");
        itemDto.setPrice(10000);
        itemDto.setRegTime(LocalDateTime.now());
        model.addAttribute("itemDto",itemDto);
        return "thymeleafEx/Ex02.html";
    }

    @GetMapping("ex03")
    public String th03(Model model){
        List<ItemDto> itemDtoList = new ArrayList<>();
        for(int i = 1; i<=10;i++){
            ItemDto itemDto = new ItemDto();
            itemDto.setItemDetail("상품 상세 설명"+i);
            itemDto.setItemNm("테스트 상품"+i);
            itemDto.setPrice(10000*i);
            itemDto.setRegTime(LocalDateTime.now());

            itemDtoList.add(itemDto);
        }
        model.addAttribute("itemDtoList",itemDtoList);
        return "thymeleafEx/Ex03.html";

    }

    @GetMapping("ex04")
    public String th04(Model model){
        List<ItemDto> itemDtoList = new ArrayList<>();
        for(int i = 1; i<=10;i++){
            ItemDto itemDto = new ItemDto();
            itemDto.setItemDetail("상품 상세 설명"+i);
            itemDto.setItemNm("테스트 상품"+i);
            itemDto.setPrice(10000*i);
            itemDto.setRegTime(LocalDateTime.now());

            itemDtoList.add(itemDto);
        }
        model.addAttribute("itemDtoList",itemDtoList);
        return "thymeleafEx/Ex04.html";
    }

    @GetMapping("ex05")
    public String th05(){
        return "thymeleafEx/Ex05.html";
    }

    @GetMapping("ex06")
    public  String th06(String param1, String param2, Model model){
        model.addAttribute("param1",param1);
        model.addAttribute("param2",param2);
        return "thymeleafEx/Ex06.html";

    }

    @GetMapping("ex07")
    public String th07(){
        return "thymeleafEx/Ex07.html";
    }
}
